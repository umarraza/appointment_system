<?php

namespace App\Http\Controllers;

use DB;
use App\User;
use App\TimeSlot;
use App\SlotBooking;
use Illuminate\Http\Request;

class DoctorController extends Controller
{
    public function appointments()
    {
        $appointments = auth()->user()->appointments->where('status', 'pending');

        return view('backend.doctors.appointments', compact('appointments'));
    }

    public function search(Request $request)
    {
        if ($request->ajax()) {

            $doctors = User::join('doctors as doctor', 'doctor.user_id', '=', 'users.id')
                ->where('doctor.specialisation', 'LIKE', '%' . $request->get('specialisation') . '%')
                ->where('users.role','=', 'Doctor')
                ->get();
                
            return view('backend.doctors')
                ->withDoctors($doctors);
        }
    }

    public function show(User $user)
    {
        return view('backend.doctors.show', compact('user'));
    }

    public function bookSlot(Request $request)
    {
        DB::beginTransaction();

        try {
            if ($request->ajax())
            {
                $slot = TimeSlot::find($request->slot_id);
    
                $booking = SlotBooking::create([
                    'date'          => now(),
                    'pateint_id'    => auth()->user()->id,
                    'doctor_id'     => $request->doctor_id,
                    'slot_id'       => $request->slot_id,
                    'start_time'    => $slot->start_time,
                    'end_time'      => $slot->end_time,
                    'status'        => 'pending',
                ]);
            }

            DB::commit();
        } catch (\Throwable $th) {
            DB::rollback();
        }

        return redirect()->route('time_slots.index')->withSlots(auth()->user()->slots)->withMessage('success', 'Slots created successfully!');
    }
}